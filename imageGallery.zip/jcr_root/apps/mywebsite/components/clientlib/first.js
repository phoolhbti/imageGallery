/*
* This is the comment of the function
*/
function getNameFirst() {
// return the name
return "some value";}